import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const app = firebase.initializeApp({
    apiKey: "AIzaSyDAWpf5CCvgZY-s_Jy9LXOo2Ik0y-VHjS4",
    authDomain: "ahealthifyapp.firebaseapp.com",
    projectId: "ahealthifyapp",
    storageBucket: "ahealthifyapp.appspot.com",
    messagingSenderId: "988211003908",
    appId: "1:988211003908:web:3da3730f8257c565b7eb51"
});

export const auth = app.auth();
export const googleProvider = new firebase.auth.GoogleAuthProvider();
export const db = firebase.firestore();

export default app;
