import React from 'react';
import CustomNavbar from '../components/CustomNavbar';
import FooterData from '../components/Footer/FooterData';
import HealthChart from '../components/Profile/HealthChart';
import Settings from '../components/Profile/Settings';
import FooterTwo from '../components/Footer/FooterTwo';
import DailyMood from '../components/Profile/DailyMood';
import MoodTimeline from '../components/Profile/MoodTimeline';

const Profile = () => {
    return(
        <div className="body_wrapper">
            <CustomNavbar mClass="menu_tracking" nClass="mr-auto" hbtnClass="tracking_btn"/>
            <DailyMood main={true} />
            <Settings />
            <MoodTimeline />
            {/* <HealthChart /> */}
            <FooterTwo FooterData={FooterData}/>
        </div>
    )
}
export default Profile;