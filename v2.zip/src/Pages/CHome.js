import React, { useState } from 'react';
import CustomNavbar from '../components/CustomNavbar';
import TrackingActivity from '../components/TrackingActivity';
import TrackingProduct from '../components/TrackingProduct';
import FooterData from '../components/Footer/FooterData';
import FaqSection from '../components/FaqSection';
import FooterTwo from '../components/Footer/FooterTwo';
import TrackingBanner from '../components/TrackingBanner';

const CustomHome = () => {

    const [proceed, setproceed] = useState(true);

    if (proceed) {
        return (
            <>
                <div className='container py-5'>
                    <h2 className='text-center py-3 welcometext'>Welcome to <br /> DY Patil University <br /> School of Engineering and Technology </h2>
                    <div className='row justify-content-center align-items-center'>
                        <div className='col-5 col-md-3'>
                            <img className='img-fluid' src='/tlogo.png' />
                        </div>
                        <div className='col-5 col-md-3'>
                            <img className='img-fluid' src='/tlogo2.png' />
                        </div>
                    </div>
                    <h3 className='text-center py-3'>A Mini Project By <br />

                        <span className='name'>Ravimohan Kumar</span>  <br />
                        <span className='name'>Geeta Bharti</span>  <br />
                        <span className='name'>Harsh Kumar</span>  <br />

                        On  <br />

                        Mental Health Tracking using React and Firebase.</h3>
                    <div className='text-center'>
                        <button onClick={() => setproceed(false)} className='custombtn'> Proceed to Project</button>
                    </div>
                </div>
            </>
        );
    }

    return (
        <div className="body_wrapper">
            <CustomNavbar mClass="menu_tracking" nClass="mr-auto" hbtnClass="tracking_btn" />
            <TrackingBanner />
            <TrackingActivity />
            <TrackingProduct />
            <FaqSection />
            <FooterTwo FooterData={FooterData} />
        </div>
    )
}
export default CustomHome;