import React, { useCallback, useEffect, useState } from 'react'
import { Redirect, useHistory } from 'react-router-dom';
import CustomNavbar from '../components/CustomNavbar'
import FooterData from '../components/Footer/FooterData'
import FooterSecurity from '../components/Footer/FooterSecurity' 
import FooterTwo from '../components/Footer/FooterTwo';
import { useAuth } from '../context/AuthContext';
import { auth, db } from '../firebase';

export default function Login() {
    const { currentUser, provider, setCurrentUser } = useAuth();
    const [error, setError] = useState(undefined);
    const [loading, setLoading] = useState(false);
    const history = useHistory();
  
    const signInWithGoogle = useCallback(async () => {
      try {
        setError("");
        setLoading(true);
        var user = await auth.signInWithPopup(provider);
        if (user != null) {
          setCurrentUser(user.user);
          addUser(user.user);
          setLoading(false);
          history.push("/");
        } else {
          setError("Error Logging you in, Please Enable Popups.");
          setLoading(false);
        }
      } catch (error) {
        setLoading(false);
        setError("Error Logging you in, Please Enable Popups.");
      }
    }, [history, provider, setCurrentUser]);

    const addUser = async (user) => {
      console.log(user);
      await db.collection('users').doc(user['uid']).set({
        'name' : user.providerData[0]['displayName'],
        'email' : user.providerData[0]['email'],
        "phone" : user.providerData[0]['phoneNumber'],
        "photo" : user.providerData[0]['photoURL'],
        "provider" : "gmail",
      });
    }

    useEffect(() => {
      if (!currentUser) {
        // signInWithGoogle();
      }
    }, [signInWithGoogle, currentUser]);
    
    if (currentUser) {
        return <Redirect to="/profile" />;
      }

    return (
        <div className="body_wrapper">
            <CustomNavbar mClass="menu_tracking" nClass="mr-auto" hbtnClass="tracking_btn" />
            <section className="tracking_price_area sec_pad">
                <div className="container">
                    <div className="tracking_price_inner wow fadeInUp">
                        <h2>Let's Get Started</h2>
                        <p className='text-center text-white py-2'>Start getting better in just a few minutes.</p>
                        <p className='text-center py-3'>
                        <span className='custombtn text-center text-white py-2'>Please Enable popups !</span>
                        </p>
                        <div className="text-center">
                            <button onClick={signInWithGoogle} className="software_banner_btn btn_submit f_500">Continue With Google</button>
                        </div>
                    </div>
                </div>
            </section>
            <FooterTwo FooterData={FooterData} />
        </div>
    )
}
