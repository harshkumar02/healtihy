import React, { Component } from "react";
import { BrowserRouter as Router, Switch } from "react-router-dom";
/*------ Pages-----*/
import ScrollToTopRoute from "./ScrollToTopRoute";
import NotFound from "./Pages/404";
import CustomHome from "./Pages/CHome";
import { AuthProvider } from "./context/AuthContext";
import Login from "./Pages/Login";
import Profile from "./Pages/Profile";
import PrivateRoute from "./components/PrivateRoute";

class App extends Component {
  componentDidMount() {
    this.props.hideLoader();
  }
  render() {
    return (
      <AuthProvider> 
      <Router>
        <Switch>
          {/* <ScrollToTopRoute exact={true} path={"/"} component={Home} /> */}
          <ScrollToTopRoute exact={true} path={"/"} component={CustomHome} />
          <ScrollToTopRoute exact={true} path={"/login"} component={Login} />
          <PrivateRoute exact={true} path={"/profile"} component={Profile} />
          <ScrollToTopRoute component={NotFound} />
        </Switch>
      </Router>
      </AuthProvider>
    );
  }
}

export default App;
