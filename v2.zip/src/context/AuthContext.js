import React, { useState, useContext, useEffect } from "react";
import { auth, googleProvider } from "../firebase";
import "firebase/compat/auth";

const AuthContext = React.createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState();
  const [loading, setLoading] = useState(true);
  var provider = googleProvider;

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  function signInWithGoogle() {
    var provider = googleProvider;
    return auth
      .signInWithPopup(provider)
      .then((res) => {
        // console.log(res.user);
        setCurrentUser(res.user);
      })
      .catch((err) => {
        // console.log(err);
      });
  }
  async function logout() {
    await auth.signOut();
  }

  function login(email, password) {
    return auth.signInWithEmailAndPassword(email, password);
  }

  const value = {
    currentUser,
    setCurrentUser,
    signInWithGoogle,
    loading,
    provider,
    logout,
    login,
  };

  let loader = (
    <div
      style={{
        display: "flex",
        height: "100vh",
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#fff",
      }}
    >
      <img
        src="https://media3.giphy.com/media/3oEjI6SIIHBdRxXI40/200.gif"
        width="200px"
        alt="Loading"
      />
    </div>
  );

  return (
    <AuthContext.Provider value={value}>
      {loading ? loader : children}
    </AuthContext.Provider>
  );
}
