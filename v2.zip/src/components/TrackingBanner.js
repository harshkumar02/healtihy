import React from 'react'; 
const TrackingBanner =()=>{
    return(
        <section className="tracking_banner_area text-center">
            <div className="container">
                <div className="tracking_banner_content">
                    <h3>Let's Keep your mental health <strong>in check ❤️</strong> </h3>
                    <p>Track your mood and watch your productivity soar!</p>
                    {/* <img src={require ("../../img/home-tracking/tracking_banner_img.png")} alt=""/> */}
                    <img className='banner-img img-fluid' height='50vh' src="/illustration.svg" alt="Banner"/>
                </div> 
            </div>
        </section>
    )
}

export default TrackingBanner;