import React from 'react'
import { Link, NavLink } from 'react-router-dom';
import Sticky from 'react-stickynode';
import { useAuth } from '../context/AuthContext';

export default function CustomNavbar() {
    const { currentUser, logout } = useAuth();

    return (
        <Sticky top={0} innerZ={9999} activeClass="navbar_fixed">
            <header className="header_area">
                <nav className={`navbar navbar-expand-lg menu_one menu_tracking`}>
                    <div className={`container`}>
                        <Link className={`navbar-brand`} to="/"> 
                            <img src= "/healthify/logo.png" width='128' alt="logo" />
                            <img src= "/healthify/logo.png" width='128' alt="logo" /> 
                        </Link>
                        <button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="menu_toggle">
                                <span className="hamburger">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </span>
                                <span className="hamburger-cross">
                                    <span></span>
                                    <span></span>
                                </span>
                            </span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className={`navbar-nav menu ml-auto mr-auto`}>

                               {/* <li className="nav-item"><NavLink exact title="Home" className="nav-link" to="/">Home</NavLink></li>

                                <li className="nav-item"><NavLink title="About" className="nav-link" to="/about">About</NavLink></li>
  */}
                            </ul>
                            {currentUser ? <button className={`btn_get btn_hover tracking_btn logout`} onClick={logout} >Logout</button> : <a className={`btn_get btn_hover tracking_btn`} href="/login">Let's Get Started </a>}
                            {currentUser ? <a className={`btn_get btn_hover tracking_btn`} href="/profile" >Profile</a> : <></>}
                            {/* <a className={`btn_get btn_hover tracking_btn`} href="/login">Get Started</a> */}
                        </div>
                    </div>
                </nav>
            </header>
        </Sticky>
    )
}
