import React from 'react';

const TrackingActivity =()=>{
    return(
        <section className="tracking_activity_area">
            <div className="container">
                <div className="row">
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/activity_icon.png")} alt=""/> */}
                            <img src="/healthify/services/1.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Notifications</h3></a>
                                <p>When you are feeling we notify your closed ones to check on you.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/time_icon.png")} alt=""/> */}
                            <img src="/healthify/services/2.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Productive</h3></a>
                                <p>We will keep you in good health and productive.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/analyze_icon.png")} alt=""/> */}
                            <img src="/healthify/services/3.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Secure</h3></a>
                                <p>All your health data is safe and secure with us.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/analyze_icon.png")} alt=""/> */}
                            <img src="/healthify/services/4.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Mood Journal</h3></a>
                                <p>Track your mental well-being by logging in your mood & journaling your thoughts and get well detailed analysis of it.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/analyze_icon.png")} alt=""/> */}
                            <img src="/healthify/services/5.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Support</h3></a>
                                <p>Easily Reach out to some of the best Therapists near you and talk to them about how you feel.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 py-4">
                        <div className="media tracking_item">
                            {/* <img src={require ("../img/home-tracking/analyze_icon.png")} alt=""/> */}
                            <img src="/healthify/services/6.png" className='mx-4' alt="Notifications"/>
                            <div className="media-body">
                                <a href="/#"><h3 className="h_head">Happy Place</h3></a>
                                <p>Unlimited wellness content blogs, meditation, breathing exercises, educational videos & podcasts .</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default TrackingActivity;