import React, { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext';
import { db } from '../../firebase';

export default function DailyMood({ main }) {

    const [done, setdone] = useState(true);
    const [mood, setmood] = useState("");
    const { currentUser } = useAuth();


    const getTodayMood = async () => {
        var today = new Date();
        var date = today.getDay() + "-" + today.getMonth() + "-" + today.getFullYear();
        console.log(date);
        var res = await db.collection('users').doc(currentUser['uid']).collection('moods').doc(date).get();
        if (res.exists) {
            setdone(true);
            setmood(res.data()['mood']);
        } else {
            setdone(false);
        }
    }

    const setTodayMood = async (mood) => {
        var today = new Date();
        var date = today.getDay() + "-" + today.getMonth() + "-" + today.getFullYear();
        await db.collection('users').doc(currentUser['uid']).collection('moods').doc(date).set({ 'mood': mood , 'date' :   Date() ,},  {merge: true});
        getTodayMood();
    }
    
    const setTodayTalk = async (talk) => {
        var today = new Date();
        var date = today.getDay() + "-" + today.getMonth() + "-" + today.getFullYear();
        await db.collection('users').doc(currentUser['uid']).collection('moods').doc(date).set({ 'contacted': talk , },  {merge: true});
        getTodayMood();
    }

    useEffect(() => {
        getTodayMood();
    }, [])

    if (done && main) {
        return (
            <>
            </>
        );
    }
    if (done) {
        return (
            <>
                <h2>You said you are {mood} today</h2>
            </>
        );
    }

    return (
        <section className="design_tab_area sec_pad bg-white">
            <h2 className='text-center'>How are you feeling today ?</h2>
            <div className='text-center py-2'>
                <div className="btn-group text-center" role="group" aria-label="Basic example">
                    <button type="button" onClick={() => setTodayMood('Depressed 🫥')} className="btn btn-light btn-lg">Depressed 🫥</button>
                    <button type="button" onClick={() => setTodayMood('Sad 😞')} className="btn btn-light btn-lg">Sad 😞</button>
                    <button type="button" onClick={() => setTodayMood('Alright 🙁')} className="btn btn-light btn-lg">Alright 🙁</button>
                    <button type="button" onClick={() => setTodayMood('Happy 😊')} className="btn btn-light btn-lg">Happy 😊</button>
                    <button type="button" onClick={() => setTodayMood('Amazing 🤩')} className="btn btn-light btn-lg">Amazing 🤩</button>
                </div>
            </div>
            <h2 className='text-center pt-4'>Have you talked to anyone today ?</h2>
            <div className='text-center py-2'>
                <div className="btn-group text-center" role="group" aria-label="Basic example"> 
                    <button type="button" onClick={() => setTodayTalk('No 😞')} className="btn btn-danger btn-lg">No 😞</button> 
                    <button type="button" onClick={() => setTodayTalk('Yes 😊')} className="btn btn-success btn-lg">Yes 😊</button> 
                </div>
            </div>
        </section>
    )
}
