import React, { useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../firebase';
import Sectitle from '../Title/Sectitle'
import DailyMood from './DailyMood';

const Settings = () => {

    const { currentUser } = useAuth();

    const name = useRef("");
    const email = useRef("");
    const phone = useRef("");

    const updateDetails = async () => {
        if (name.current.value != "") {
            await db.collection('users').doc(currentUser['uid']).update({ 'name': name.current.value });
        }
        if (email.current.value != "") {
            await db.collection('users').doc(currentUser['uid']).update({ 'email': email.current.value });
        }
        if (phone.current.value != "") {
            await db.collection('users').doc(currentUser['uid']).update({ 'phone': phone.current.value });
        }
        getDetails();
    }

    const getDetails = async () => {
        var data = await db.collection('users').doc(currentUser['uid']).get();
        try {

            name.current.value = data.data()['name'];
            email.current.value = data.data()['email'];
            phone.current.value = data.data()['phone'];
        } catch (error) {

        }
    }

    useEffect(() => {
        getDetails();
    }, [])


    return (
        <section className="design_tab_area sec_pad">
            <div className="container">
                <Sectitle sClass="sec_title text-center mb_70" Title='Your Space 🪐' TitleP='' />
                <div className="row">
                    <div className="col-lg-4 d-flex align-items-center">
                        <ul className="nav nav-tabs design_tab support_tab" role="tablist">
                            <li className="nav-item wow fadeInUp" data-wow-delay="0.4s">
                                <a className="nav-link active" id="one-tab" data-toggle="tab" href="#one" role="tab" aria-controls="one" aria-selected="true">
                                    <h5>Your Profile</h5>
                                    <p>View and Update your Details.</p>
                                </a>
                            </li>
                            <li className="nav-item wow fadeInUp" data-wow-delay="0.6s">
                                <a className="nav-link" id="two-tab" data-toggle="tab" href="#two" role="tab" aria-controls="two" aria-selected="false">
                                    <h5>Mood Today</h5>
                                    <p>How are you feeling today ?</p>
                                </a>
                            </li>
                            {/* <li className="nav-item wow fadeInUp" data-wow-delay="0.8s">
                                <a className="nav-link" id="three-tab" data-toggle="tab" href="#three" role="tab" aria-controls="three" aria-selected="false">
                                    <h5>Easy to maintain</h5>
                                    <p>Design to development,<br /> automated</p>
                                </a>
                            </li> */}
                        </ul>
                    </div>
                    <div className="col-lg-8">
                        <div className="tab-content card p-4 support_tab_content">
                            <div className="tab-pane fade show active" id="one" role="tabpanel" aria-labelledby="one-tab">
                                {/* <div className="tab_img"> */}
                                {/* <img src={require ("../../img/new-home/tab_2.png")} alt=""/> */}
                                {/* </div> */}
                                <div>
                                    <h2>Your Profile</h2>
                                    <div className='row'>
                                        <div className='col-12 col-md-12 col-lg-6'>
                                            <div className='form-group'>
                                                <input placeholder='Name' ref={name} className='form-control form-control-lg' />
                                            </div>
                                        </div>
                                        <div className='col-12 col-md-12 col-lg-6'>
                                            <div className='form-group'>
                                                <input placeholder='Email' ref={email} className='form-control form-control-lg' />
                                            </div>
                                        </div>
                                        <div className='col-12 col-md-12 col-lg-6'>
                                            <div className='form-group'>
                                                <input placeholder='Phone Number' ref={phone} className='form-control form-control-lg' />
                                            </div>
                                        </div>
                                        <div className='col-12 col-md-12 col-lg-12'>
                                            <button className='btn btn-lg btn-success' onClick={updateDetails}>Update</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="tab-pane fade" id="two" role="tabpanel" aria-labelledby="two-tab">
                                {/* <div className="tab_img">
                                    <img src={require("../../img/new-home/tab.png")} alt="" />
                                </div> */}
                                <DailyMood main={false} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Settings;