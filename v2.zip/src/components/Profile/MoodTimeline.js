import React, { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext';
import { db } from '../../firebase';
export default function MoodTimeline() {

    const { currentUser } = useAuth();
    const [data, setData] = useState([]);


    const getData = async () => {
        var today = new Date();
        var date = today.getDay() + "-" + today.getMonth() + "-" + today.getFullYear();
        console.log(date);
        var res = await db.collection('users').doc(currentUser['uid']).collection('moods').where('date', '<=', Date(),).limit(7).get();
        console.log(res.docs);
        setData(res.docs);
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <>
            <div className='container py-4'>
                <h3 className='text-center'>Here's you recent Mood</h3>
                <div className='row'>
                    {data.map((doc) => (
                        <div className='col-11 col-md-6 col-lg-4 card p-2 text-center'>
                            <h4>Mood : {doc.data()['mood']}</h4>
                            <h4>Talke To Anyone : {doc.data()['contacted']}</h4>
                            </div>
                    ))}
                </div>
            </div>
        </>
    )
}
